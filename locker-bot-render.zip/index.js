const express = require('express');    
const multer = require('multer');    
const login = require('ws3-fca');    
const path = require('path');    
const fs = require('fs');    
    
const app = express();    
const PORT = process.env.PORT || 5000;    
    
const upload = multer({ dest: 'uploads/' });    
    
let botConfig = null;    
let apiInstance = null;    
    
app.use(express.urlencoded({ extended: true }));    
app.use(express.static('public'));    
    
app.get('/', (req, res) => {    
    res.send('<h2>Kartik Rajput Locker Bot Panel Running ✅</h2>');    
});    
    
app.listen(PORT, '0.0.0.0', () => {    
    console.log(`🌐 Web panel running on http://0.0.0.0:${PORT}`);    
});    
